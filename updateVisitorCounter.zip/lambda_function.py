import json
import boto3

client = boto3.client('dynamodb')

def lambda_handler(event, context):
    data = client.update_item(
        TableName='resumeVisits',
        Key={
            'resumeViewCounts': {
                'S': 'resumeViewCount',
            },
        },
        ExpressionAttributeValues={
            ':inc': {
                'N': '1'
            }
        },
        UpdateExpression= "ADD viewCount :inc",

    )
    
    data_get = client.get_item(
        TableName='resumeVisits',
        Key={
            'resumeViewCounts': {
                'S': 'resumeViewCount',
            }
        }
    )
    
    response = {
        'statusCode': 200,
        'body': json.dumps(data_get),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'OPTIONS,PATCH',
        },
    }
    
    return response